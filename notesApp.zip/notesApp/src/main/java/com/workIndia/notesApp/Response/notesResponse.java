package com.workIndia.notesApp.Response;

import org.json.JSONObject;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

@Component
public class notesResponse {

	public ResponseEntity<Object> success_response()
	{
		JSONObject success_json=new JSONObject();
		success_json.put("status","account created");
		return new ResponseEntity<>(success_json.toMap(),HttpStatus.OK);
	}
	
	public ResponseEntity<Object> success_responseWithID(int id)
	{
		JSONObject success_json=new JSONObject();
		success_json.put("status","account created");
		success_json.put("userId",id);

		
		return new ResponseEntity<>(success_json.toMap(),HttpStatus.OK);
	}
	public ResponseEntity<Object> failure_response()
	{
		JSONObject failure_json=new JSONObject();
		failure_json.put("status","failure");
		return new ResponseEntity<>(failure_json.toMap(),HttpStatus.BAD_REQUEST);
	}
}
