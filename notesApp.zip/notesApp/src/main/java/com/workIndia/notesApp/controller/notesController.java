package com.workIndia.notesApp.controller;


import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.workIndia.notesApp.DAOImp.notesDAO;
import com.workIndia.notesApp.Repository.notesRepository;
import com.workIndia.notesApp.Request.notesRequest;
import com.workIndia.notesApp.Response.notesResponse;

@RestController
public class notesController
{
	@Autowired
	notesRepository repo;
	
	@Autowired
	notesResponse resp;
	
	@Autowired
	notesDAO dao;

	@PostMapping(path="/app/user",consumes= {"application/json"})
	public ResponseEntity<Object> createAccount(@RequestBody notesRequest notes)
	{
		String username=notes.getUsername();
		String password=notes.getPassword();
		if(username==null || password==null)
			return resp.failure_response();
		else
			{	
			 repo.save(notes);
			 return resp.success_response();
			}
		
	}
	
	@PostMapping(path="/app/user/auth",consumes= {"application/json"})
	public ResponseEntity<Object> loginAccount(@RequestBody notesRequest notes)
	{
		String username=notes.getUsername();
		String password=notes.getPassword();
		if(username==null || password==null)
			return resp.failure_response();
		else
			{	
				List<notesRequest> user_list=dao.findByUsernameAndPassword(username, password);
				 if(user_list.size()==0)
					 return null;
				 notesRequest obj=user_list.get(0);
				 int userID=obj.getUser();
				 return resp.success_responseWithID(userID);
				
			}
	}
	
	@GetMapping(path="/app/sites/list/?user={userId}",consumes= {"application/json"})
	public Optional<notesRequest> getAllNotes(@PathVariable(value="userId") int userId)
	{
		return repo.findById(userId);

	}
	
	@PostMapping(path="/app/sites/?user={userId}",consumes= {"application/json"})
	public ResponseEntity<Object> saveNote(@RequestBody notesRequest notes)
	{
		 repo.save(notes);
		 return resp.success_response();
	}
	
	
	
	
}