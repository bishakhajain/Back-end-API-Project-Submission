package com.workIndia.notesApp.DAOImp;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.workIndia.notesApp.Repository.notesRepository;
import com.workIndia.notesApp.Request.notesRequest;

@Component
public class notesDAO {
	
	@Autowired
	notesRepository repo;
	
	
	public List<notesRequest> findByUsernameAndPassword(String username,String password)
	{
		return repo.findByUsernameAndPassword(username,password);
	}
}
